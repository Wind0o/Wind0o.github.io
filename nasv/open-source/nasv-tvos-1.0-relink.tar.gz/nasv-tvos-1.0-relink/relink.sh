#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
SDK="$(xcrun --sdk appletvos --show-sdk-path)"
TOOLCHAIN="$(xcode-select -p)/Toolchains/XcodeDefault.xctoolchain"
mkdir -p out
xcrun --sdk appletvos clang -target arm64-apple-tvos17.0 -isysroot "$SDK" -Os \
 -Xlinker -reproducible -Xlinker -no_warn_duplicate_libraries \
 -Llib -L"$TOOLCHAIN/usr/lib/swift/appletvos" -L/usr/lib/swift \
 -filelist objects.txt -Xlinker -rpath -Xlinker /usr/lib/swift \
 -Xlinker -rpath -Xlinker @executable_path/Frameworks -Xlinker -dead_strip \
 -fobjc-arc -fobjc-link-runtime -lavformat -lavcodec -lswscale -lswresample \
 -lavutil -ldav1d -lbz2 -lz -liconv -framework VideoToolbox \
 -framework AudioToolbox -framework CoreMedia -framework CoreVideo \
 -framework Security -o out/NasV
file out/NasV
