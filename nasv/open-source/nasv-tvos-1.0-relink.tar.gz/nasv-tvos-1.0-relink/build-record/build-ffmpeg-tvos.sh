#!/bin/sh
# Cross-compile FFmpeg (decode-only, LGPL) for appletvos arm64.
# Output: Vendor/ffmpeg/tvos-arm64/{include,lib}
set -eu

PROJECT_ROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)"
export DEVELOPER_DIR="${DEVELOPER_DIR:-/Users/einek_1/Xcode-beta.app/Contents/Developer}"
SDK="$(xcrun --sdk appletvos --show-sdk-path)"
MINVER="17.0"
ARCH="arm64"
PREFIX="${PROJECT_ROOT}/Vendor/ffmpeg/tvos-arm64"
SRC="${PROJECT_ROOT}/Vendor/ffmpeg/src"
DAV1D_INC="${PROJECT_ROOT}/Vendor/dav1d/include"
DAV1D_LIB="${PROJECT_ROOT}/Vendor/dav1d/lib-tvos"
JOBS="$(sysctl -n hw.ncpu 2>/dev/null || echo 4)"

if [ ! -f "${SDK}/SDKSettings.plist" ]; then
  echo "error: appletvos SDK missing at ${SDK}" >&2
  exit 1
fi
if [ ! -f "${DAV1D_LIB}/libdav1d.a" ]; then
  echo "error: tvOS libdav1d.a missing" >&2
  exit 1
fi

TARBALL="${1:-/tmp/ffmpeg-8.0.tar.xz}"
if [ ! -f "$TARBALL" ]; then
  echo "downloading ffmpeg 8.0…"
  curl -L --retry 3 -o "$TARBALL" "https://ffmpeg.org/releases/ffmpeg-8.0.tar.xz"
fi

rm -rf "$SRC"
mkdir -p "$SRC"
echo "extract ${TARBALL}…"
tar -xJf "$TARBALL" -C "$SRC" --strip-components=1

CC="$(xcrun --sdk appletvos -f clang)"
AR="$(xcrun --sdk appletvos -f ar)"
mkdir -p "${PREFIX}/bin"
cat > "${PREFIX}/bin/pkg-config" <<EOF
#!/bin/sh
# Tiny pkg-config so FFmpeg configure can find our vendored libdav1d.
case "\$*" in
  *--version*) echo 0.29.2; exit 0 ;;
  *dav1d*)
    case "\$*" in
      *--exists*) exit 0 ;;
      *--modversion*) echo 1.4.0; exit 0 ;;
      *--cflags*) echo "-I${DAV1D_INC}"; exit 0 ;;
      *--libs*) echo "-L${DAV1D_LIB} -ldav1d"; exit 0 ;;
    esac
    echo "-I${DAV1D_INC} -L${DAV1D_LIB} -ldav1d"
    exit 0
    ;;
esac
exit 1
EOF
chmod +x "${PREFIX}/bin/pkg-config"
export PATH="${PREFIX}/bin:${PATH}"

cd "$SRC"
echo "configure FFmpeg for appletvos ${ARCH}…"
./configure \
  --prefix="$PREFIX" \
  --enable-cross-compile \
  --target-os=darwin \
  --arch=aarch64 \
  --cc="$CC" \
  --ar="$AR" \
  --extra-cflags="-arch ${ARCH} -isysroot ${SDK} -mappletvos-version-min=${MINVER} -fPIC -I${DAV1D_INC}" \
  --extra-ldflags="-arch ${ARCH} -isysroot ${SDK} -mappletvos-version-min=${MINVER} -L${DAV1D_LIB}" \
  --disable-programs \
  --disable-doc \
  --disable-debug \
  --disable-asm \
  --enable-pic \
  --enable-static \
  --disable-shared \
  --disable-avdevice \
  --enable-network \
  --disable-encoders \
  --disable-muxers \
  --disable-filters \
  --disable-devices \
  --enable-avformat \
  --enable-avcodec \
  --enable-avutil \
  --enable-swscale \
  --enable-swresample \
  --enable-zlib \
  --enable-libdav1d \
  --enable-hwaccel=h264_videotoolbox \
  --enable-hwaccel=hevc_videotoolbox \
  --enable-hwaccel=av1_videotoolbox \
  --enable-protocol=file,http,https,tcp,tls,crypto \
  --enable-demuxer=mov,matroska,mpegts,avi,flv,asf,ogg,wav,mp3,aac,flac,hls,dash,mpegvideo,mpegps \
  --enable-parser=h264,hevc,aac,mpeg4video,mpegvideo,vp9,vp8,av1,opus,vorbis,flac,mpegaudio,ac3 \
  --enable-decoder=h264,hevc,mpeg4,mpeg2video,mpeg1video,vp9,vp8,libdav1d,av1,aac,mp3,mp2,ac3,eac3,flac,opus,vorbis,pcm_s16le,alac,mjpeg \
  --pkg-config="${PREFIX}/bin/pkg-config"

echo "make -j${JOBS}…"
make -j"${JOBS}"
make install
echo "done → ${PREFIX}"
ls -lh "${PREFIX}/lib"
